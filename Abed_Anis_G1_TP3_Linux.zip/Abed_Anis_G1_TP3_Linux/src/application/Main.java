package application;
	
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Main extends Application{
	
	public void start(Stage primaryStage) throws IOException, InterruptedException  {
			URL url;
			try {
				url = new File("src/application/SplashScreen.fxml").toURI().toURL();
				Parent root = FXMLLoader.load(url);
				Scene scene = new Scene(root);
				primaryStage.setTitle("Gestion De Bibliothèque");
		        primaryStage.setScene(scene);
		        primaryStage.show();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();}
	}       	
	public static void main(String[] args) {
		launch(args);
	}
}

