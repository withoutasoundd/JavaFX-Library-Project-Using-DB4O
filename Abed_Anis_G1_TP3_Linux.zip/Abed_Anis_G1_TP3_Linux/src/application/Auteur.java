package application;

public class Auteur {
	private String id_a;
	private String nom;
	private String prenom;
	private String date_n;
	private String lieu_n;
	private String adr_a;
	
	public Auteur(String id_a, String nom, String prenom, String date_n, String lieu_n, String adr_a) {
		this.id_a=id_a;
		this.nom=nom;
		this.prenom=prenom;
		this.date_n=date_n;
		this.lieu_n=lieu_n;
		this.adr_a=adr_a;
	}
	
	@Override
	public String toString() {
		return "Nom : "+nom+"\nPrenom : "+prenom+"\nNé le : "+date_n+ "\nLieu : "+lieu_n+"\nHabite à : "+adr_a;
	}

	public String getId_a() {
		return id_a;
	}

	public void setId_a(String id_a) {
		this.id_a = id_a;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getDate_n() {
		return date_n;
	}

	public void setDate_n(String date_n) {
		this.date_n = date_n;
	}

	public String getLieu_n() {
		return lieu_n;
	}

	public void setLieu_n(String lieu_n) {
		this.lieu_n = lieu_n;
	}

	public String getAdr_a() {
		return adr_a;
	}

	public void setAdr_a(String adr_a) {
		this.adr_a = adr_a;
	}
}
