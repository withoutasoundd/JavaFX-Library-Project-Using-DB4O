package application;

public class Editeur {
	private String id_e;
	private String m_e;
	private String adr_e;
	
	public Editeur(String id_e,String m_e,String adr_e ) {
		this.id_e=id_e;
		this.m_e=m_e;
		this.adr_e=adr_e;
	}
	
	public Editeur() {}
	
	public String toString() {
		return "Maison d'edition : "+m_e+"\nAdresse : "+adr_e;}
	
	public String getAdr_e() {
		return adr_e;
	}
	public String getId_e() {
		return id_e;
	}
	public String getM_e() {
		return m_e;
	}
	public void setAdr_e(String adr_e) {
		this.adr_e = adr_e;
	}
	public void setId_e(String id_e) {
		this.id_e = id_e;
	}
	public void setM_e(String m_e) {
		this.m_e = m_e;
	}
}
