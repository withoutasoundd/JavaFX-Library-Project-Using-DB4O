package application;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SplashScreen_Controller {
	@FXML
	Button b1;

	public void loadmain() throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("Main_Screen.fxml"));
		Stage window = (Stage) b1.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
				
	}	
}