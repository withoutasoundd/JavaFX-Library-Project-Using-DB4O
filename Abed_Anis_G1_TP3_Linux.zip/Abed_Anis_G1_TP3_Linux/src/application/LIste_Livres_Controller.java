package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class LIste_Livres_Controller {
	
	@FXML Button afficher; @FXML AnchorPane apne; @FXML VBox vbox; @FXML ImageView back;
	static ObjectContainer db;
	public void afficher() {
	String path = System.getProperty("user.home")+"/bibliotheque.db4o";
		
		db = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), path);
		try {
			vbox.setSpacing(25);
			List <Livre> e = db.query(Livre.class);
			Label res = new Label();
			res.setText(e.size()+" Livre(s) trouvé(s).");
			res.setFont(new Font("DejaVu Sans", 28));
			res.setStyle("-fx-text-fill: green;");
			vbox.getChildren().add(res);
			for(int i=0; i<e.size();i++) {
				HBox v1 = new HBox();
				v1.setSpacing(15);
				Label book = new Label("("+(i+1)+")\n"+e.get(i).toString());
				book.setFont(new Font("DejaVu Sans", 24));
		        book.setStyle("-fx-background-color: #ADD8E6");
		        Label author = new Label("Auteur :\n"+e.get(i).getAuteur().toString());
				author.setFont(new Font("DejaVu Sans", 24));
		        author.setStyle("-fx-background-color: #ffcccb");
				Label editor = new Label("Editeur :\n"+e.get(i).getEditeur().toString()+"\n\n\n\n");
				editor.setFont(new Font("DejaVu Sans", 24));
		        editor.setStyle("-fx-background-color: #FFD580");
		        HBox.setHgrow(book, Priority.ALWAYS);
		        HBox.setHgrow(author, Priority.ALWAYS);
		        HBox.setHgrow(editor, Priority.ALWAYS);
		        book.setPrefWidth(349);
		        author.setPrefWidth(349);
		        editor.setPrefWidth(349);

				v1.getChildren().addAll(book,author,editor);
				vbox.getChildren().add(v1);
			}}
		
		finally {
			db.close();
		}}
	
	public void back() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Main_Screen.fxml"));
		Stage window = (Stage) back.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));}
 
}
