package application;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Main_Screen_Controller {

	@FXML
	Button l1; @FXML Button l2; @FXML Button l3; @FXML Button a1; @FXML Button a2; @FXML Button a3; @FXML Button e1; @FXML
	Button e2; @FXML Button e3;
	
	public void l_l() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Liste_Livres.fxml"));
		Stage window = (Stage) l1.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void a_l() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("AJouter_Livre.fxml"));
		Stage window = (Stage) l2.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void r_l() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Rechercher_Livre.fxml"));
		Stage window = (Stage) l3.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void l_a() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Liste_Auteurs.fxml"));
		Stage window = (Stage) a1.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void a_a() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Ajouter_Auteur.fxml"));
		Stage window = (Stage) a2.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void r_a() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Rechercher_Auteur.fxml"));
		Stage window = (Stage) a3.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void l_e() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Liste_Editeur.fxml"));
		Stage window = (Stage) e1.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void a_e() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Ajouter_Editeur.fxml"));
		Stage window = (Stage) e2.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
	public void r_e() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Rechercher_Editeur.fxml"));
		Stage window = (Stage) e3.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
	}
}
