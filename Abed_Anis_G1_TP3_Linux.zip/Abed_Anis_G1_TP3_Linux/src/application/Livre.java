package application;

public class Livre {
	private String id_l;
	private String titre;
	private String ISBN;
	private Auteur auteur;
	private Editeur editeur;
	private String annee_e;
	private String domaine;
	private String mot_cles;
	
	public Livre(String id_l, String titre, String ISBN,String annee_e, String domaine, String mot_cles) {
		this.id_l=id_l;
		this.titre=titre;
		this.ISBN=ISBN;
		this.auteur=null;
		this.editeur=null;
		this.annee_e=annee_e;
		this.domaine=domaine;
		this.mot_cles=mot_cles;
	}
	
	@Override
	public String toString() {
		return "Titre : "+titre+"\nISBN : "+ISBN+"\nAnnée d'edition : "+annee_e+"\nDomaine : "+annee_e+"\nMot clés : ["+mot_cles+"]";
	}

	public String getId_l() {
		return id_l;
	}

	public void setId_l(String id_l) {
		this.id_l = id_l;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public Auteur getAuteur() {
		return auteur;
	}

	public void setAuteur(Auteur auteur) {
		this.auteur = auteur;
	}

	public Editeur getEditeur() {
		return editeur;
	}

	public void setEditeur(Editeur editeur) {
		this.editeur = editeur;
	}

	public String getAnnee_e() {
		return annee_e;
	}

	public void setAnnee_e(String annee_e) {
		this.annee_e = annee_e;
	}

	public String getDomaine() {
		return domaine;
	}

	public void setDomaine(String domaine) {
		this.domaine = domaine;
	}

	public String getMot_cles() {
		return mot_cles;
	}

	public void setMot_cles(String mot_cles) {
		this.mot_cles = mot_cles;
	}	

}