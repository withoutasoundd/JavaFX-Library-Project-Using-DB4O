package application;

import java.io.IOException;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Ajouter_Editeur_Controller {
	static ObjectContainer db;
	
	@FXML ImageView back; @FXML Button add; @FXML TextField id; @FXML TextField maison; @FXML TextField adresse; @FXML Label added;

	 public void back() throws IOException {
			Parent root = FXMLLoader.load(getClass().getResource("Main_Screen.fxml"));
			Stage window = (Stage) back.getScene().getWindow();
			window.setScene(new Scene(root, 1100, 650));
	 }
	 
	 
	 public void add() {
		 
		 if (!id.getText().isEmpty()&&!maison.getText().isEmpty()&&!adresse.getText().isEmpty()) {
			 String path = System.getProperty("user.home")+"/bibliotheque.db4o";
				
				db = Db4oEmbedded.openFile(Db4oEmbedded
						.newConfiguration(), path);
			try {
				 String idd = id.getText().toString();
				 String maisonn = maison.getText().toString();
				 String adr = adresse.getText().toString();
				 
				 Editeur ed = new Editeur(idd,maisonn,adr);
				 db.store(ed);
				 id.clear(); maison.clear(); adresse.clear(); added.setText("");
				 added.setStyle("-fx-text-fill: green;");
				 added.setText("Ajouté avec Succées");
			}
			 finally {
				 db.close();
			 }
		 }
 
		 else {
			 added.setStyle("-fx-text-fill: red;");
			 added.setText("Veuillez remplir tous les champs !");
		 }
	 }
}
