package application;

import java.io.IOException;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Rechercher_Editeur_Controller {
	
	@FXML Button afficher; @FXML AnchorPane apne; @FXML VBox vbox; @FXML ImageView back; @FXML TextField search;
	static ObjectContainer db;

	public void afficher() {
	vbox.getChildren().clear();
	String path = System.getProperty("user.home")+"/bibliotheque.db4o";
		
		db = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), path);
		try {
			vbox.setSpacing(10);
			Query query=db.query();
			query.constrain(Editeur.class);
			query.descend("m_e").constrain(search.getText().toString());
			ObjectSet result=query.execute();
			listResult(result);
			Label res = new Label();
			res.setText(result.size()+" Resultat(s) trouvé(s).");
			res.setFont(new Font("DejaVu Sans", 28));
			res.setStyle("-fx-text-fill: green;");
			vbox.getChildren().add(res);
			for(int i=0; i<result.size();i++) {
				VBox v1 = new VBox();
		        v1.setStyle("-fx-background-color: #ADD8E6");
				Label label = new Label("("+(i+1)+")\n"+result.get(i).toString());
				label.setFont(new Font("DejaVu Sans", 24));
				v1.getChildren().add(label);
				vbox.getChildren().add(v1);
			}}
		
		finally {
			db.close();
		}}
	
	public void back() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Main_Screen.fxml"));
		Stage window = (Stage) back.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));
 }
	public static void listResult(List<?> result){
		System.out.println(result.size());
		for (Object o : result) {
			System.out.println(o);
		}
		}
		}
 
	
