package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Liste_Auteurs_Controller {
	
	@FXML Button afficher; @FXML AnchorPane apne; @FXML VBox vbox; @FXML ImageView back;
	static ObjectContainer db;
	public void afficher() {
	String path = System.getProperty("user.home")+"/bibliotheque.db4o";
		
		db = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), path);
		try {
			vbox.setSpacing(10);
			List <Auteur> e = db.query(Auteur.class);
			Label res = new Label();
			res.setText(e.size()+" Auteur(s) trouvé(s).");
			res.setFont(new Font("DejaVu Sans", 28));
			res.setStyle("-fx-text-fill: green;");
			vbox.getChildren().add(res);
			for(int i=0; i<e.size();i++) {
				VBox v1 = new VBox();
		        v1.setStyle("-fx-background-color: #ADD8E6");
				Label label = new Label("("+(i+1)+")\n"+e.get(i).toString());
				label.setFont(new Font("DejaVu Sans", 24));
				v1.getChildren().add(label);
				vbox.getChildren().add(v1);
			}}
		
		finally {
			db.close();
		}}
	
	public void back() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Main_Screen.fxml"));
		Stage window = (Stage) back.getScene().getWindow();
		window.setScene(new Scene(root, 1100, 650));}
 
}
