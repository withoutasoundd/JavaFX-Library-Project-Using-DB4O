module Abed_Anis_G1_TP3 {
	requires javafx.controls;
	requires db4o;
	requires javafx.fxml;
	
	opens application to javafx.graphics, javafx.fxml,db4o;
}
